@extends('admin.layouts.app')
@section('content')
    <style>
        li{
            text-align: center;
        }
        @media (min-width: 564px) {
            .daterangepicker .ranges ul {
                width: 160px;
            }
        }
        .range_inputs{
            text-align: center;
            padding-bottom: 10px;
        }
    </style>
    <section class="content__box content__box--shadow">
        <div class="  details-of-orders">
            <div class="row">
                <div class="col-sm-4">
                    <label>Select Date</label>
                    <form name="abcaaa" method="get" action="">
                        <div class="input-group">
                            <input type="text" name="sales_date" id="reportrange" class="form-control">
                            <span class="input-group-addon report_filter">Filter</span>
                        </div>
                    </form>

                </div>
                <div class="col-sm-6">
                    {{--<a href="{{ route('admin.sales-report.excel') }}" class="btn btn-primary pull-right"> Export to Excel </a>--}}
                </div>
            </div>



            <div class="clearfix"></div>
        </div>
    </section>
    <div class="content__box content__box--shadow">
            <div id="salesReport">
                @include('admin.sales_report.report')
            </div>
    </div>
@endsection

@push('scripts')

<script>
    $(function(){
        $('.btn-excel').click(function(e){
            e.preventDefault();
            var salesdate = $('#reportrange').val();
//            console.log(price);
            console.log(salesdate);


            if (salesdate) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url:"{{ route('admin.sales-report.excel') }}",
                    data: {
                        product: salesdate
                    }
                });
            }

        });

    });



    function(){



    }

</script>


<script>
    $(function(){
        $('.report_filter').click(function(e){
//            e.preventDefault();
            $('#salesReport').html('<div id="loaderpro" style="" ></div>');
            var salesdate = $('#reportrange').val();
//            console.log(price);
//            console.log(salesdate);


            if (salesdate) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url:"{{ route('admin.sales-report.filter') }}",
                    data: {
                        product: salesdate
                    },
                    success:function(result){
                        $('#salesReport').replaceWith($('#salesReport').html(result));

                        $('#myTable').DataTable({
                            aaSorting: [0,'desc'],
                            processing: true,
                            serverSide: true,
                            columns: [
                                {
                                    "data": "id"},
                                {data: 'product_name'},
                                {data: 'price'},
                                {data: 'tax'},
                                {data: 'shipping'},
                                {data: 'discount'},
                                {data: 'grandTotal'},

                            ],
                            ajax: {

                                url: '{{route('admin.sales-report.json')}}',
                                type:'get',
                                data: {
                                    product: salesdate
                                },


                            }

                        });
                    }
                });
            }

        });

    });



</script>

<script>

    $(document).ready(function(){
        $('#myTable').DataTable({
            aaSorting: [0,'desc'],
            processing: true,
            serverSide: true,
            columns: [
                {
                    "data": "id"},
                {data: 'product_name'},
                {data: 'price'},
                {data: 'tax'},
                {data: 'shipping'},
                {data: 'discount'},
                {data: 'grandTotal'},

            ],
            ajax: '{{route('admin.sales-report.json')}}'

        });
    });
</script>

@endpush